const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const scoreLabel = document.getElementById('score');
const bestLabel = document.getElementById('bestScore');
const overlay = document.getElementById('overlay');
const overlayTitle = document.getElementById('overlayTitle');
const overlayText = document.getElementById('overlayText');
const startButton = document.getElementById('startButton');

const W = canvas.width;
const H = canvas.height;
const keys = { left: false, right: false };
let player, clouds, particles, score, bestScore, running, lastTime, spawnTimer, elapsed;

try { bestScore = Number(localStorage.getItem('langitCeriaBest')) || 0; } catch (_) { bestScore = 0; }
bestLabel.textContent = bestScore;

function roundedRect(x, y, width, height, radius) {
  ctx.beginPath();
  ctx.roundRect(x, y, width, height, radius);
}

function drawBackground(time = 0) {
  const sky = ctx.createLinearGradient(0, 0, 0, H);
  sky.addColorStop(0, '#b9e5ff');
  sky.addColorStop(1, '#e6f7ff');
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, W, H);

  // Soft distant cloud banks
  for (let i = 0; i < 5; i++) {
    const x = ((i * 205 + time * 0.012) % (W + 210)) - 100;
    const y = 54 + (i % 3) * 84;
    ctx.globalAlpha = 0.38;
    drawCloudShape(x, y, 1.25, '#ffffff', false);
  }
  ctx.globalAlpha = 1;
  ctx.fillStyle = 'rgba(255,255,255,.46)';
  ctx.beginPath();
  ctx.arc(690, 75, 35, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(255,246,202,.82)';
  ctx.beginPath();
  ctx.arc(690, 75, 24, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#ffe18d';
  ctx.beginPath();
  ctx.arc(690, 75, 17, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
}

function drawCloudShape(x, y, scale, color, face = true) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);

  // Grounding shadow makes the cloud appear to float above the sky.
  ctx.fillStyle = 'rgba(63, 107, 151, .18)';
  ctx.beginPath();
  ctx.ellipse(0, 16, 47, 12, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(-43, 8);
  ctx.bezierCurveTo(-57, 7, -59, -8, -49, -16);
  ctx.bezierCurveTo(-45, -28, -30, -31, -21, -23);
  ctx.bezierCurveTo(-16, -44, 11, -46, 20, -24);
  ctx.bezierCurveTo(40, -30, 52, -15, 47, -1);
  ctx.bezierCurveTo(60, 10, 48, 18, 35, 18);
  ctx.lineTo(-34, 18);
  ctx.bezierCurveTo(-45, 18, -51, 14, -43, 8);
  ctx.closePath();
  ctx.shadowColor = 'rgba(75, 117, 154, .28)';
  ctx.shadowBlur = 10;
  ctx.shadowOffsetY = 5;
  const body = ctx.createLinearGradient(0, -38, 0, 20);
  body.addColorStop(0, '#ffffff');
  body.addColorStop(.48, color);
  body.addColorStop(1, '#d9eaf5');
  ctx.fillStyle = body;
  ctx.fill();
  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;
  ctx.strokeStyle = 'rgba(112, 159, 190, .38)';
  ctx.lineWidth = 1.3;
  ctx.stroke();

  // Soft glossy highlight gives the cloud a rounded, puffy surface.
  ctx.save();
  ctx.clip();
  const shine = ctx.createRadialGradient(-19, -25, 2, -12, -12, 48);
  shine.addColorStop(0, 'rgba(255,255,255,.82)');
  shine.addColorStop(.55, 'rgba(255,255,255,.22)');
  shine.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = shine;
  ctx.fillRect(-60, -50, 120, 75);
  const shade = ctx.createLinearGradient(0, 1, 0, 20);
  shade.addColorStop(0, 'rgba(111,157,187,0)');
  shade.addColorStop(1, 'rgba(111,157,187,.20)');
  ctx.fillStyle = shade;
  ctx.fillRect(-60, 0, 120, 25);
  ctx.restore();

  if (face) {
    ctx.fillStyle = '#627c99';
    ctx.beginPath(); ctx.ellipse(-11, -5, 2.2, 3, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(10, -5, 2.2, 3, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#8299ad';
    ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.arc(0, -1, 5, .25, Math.PI - .25); ctx.stroke();
    ctx.fillStyle = 'rgba(255, 143, 157, .52)';
    ctx.beginPath(); ctx.ellipse(-20, 2, 5, 2.5, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(20, 2, 5, 2.5, 0, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();
}

function drawUmbrella(x, y, time = 0) {
  ctx.save();
  ctx.translate(x, y + Math.sin(time * 0.006) * 3);

  // Soft cast shadow underneath the umbrella.
  ctx.fillStyle = 'rgba(69, 105, 145, .20)';
  ctx.beginPath();
  ctx.ellipse(0, 10, 31, 7, 0, 0, Math.PI * 2);
  ctx.fill();

  // Metallic-looking handle, drawn behind the canopy.
  ctx.strokeStyle = '#56496f';
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 1); ctx.lineTo(0, 39); ctx.quadraticCurveTo(0, 50, 9, 50);
  ctx.stroke();
  ctx.strokeStyle = '#c8b8dc';
  ctx.lineWidth = 1.7;
  ctx.beginPath(); ctx.moveTo(-1.5, 9); ctx.lineTo(-1.5, 32); ctx.stroke();

  const colors = ['#ff7892', '#ff9f88', '#ffd56f', '#73d5c3', '#83b7ff'];
  for (let i = 0; i < 5; i++) {
    const a1 = Math.PI + i * Math.PI / 5;
    const a2 = Math.PI + (i + 1) * Math.PI / 5;
    const panel = ctx.createLinearGradient(0, -35, 0, 5);
    panel.addColorStop(0, '#ffffff');
    panel.addColorStop(.16, colors[i]);
    panel.addColorStop(1, colors[i]);
    ctx.fillStyle = panel;
    ctx.shadowColor = 'rgba(83, 77, 119, .25)';
    ctx.shadowBlur = 8;
    ctx.shadowOffsetY = 3;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, 34, a1, a2);
    ctx.lineTo(0, 0);
    ctx.closePath();
    ctx.fill();
    ctx.shadowColor = 'transparent';
    ctx.shadowBlur = 0;
    ctx.shadowOffsetY = 0;
    ctx.strokeStyle = 'rgba(255,255,255,.8)';
    ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(34 * Math.cos(a2), 34 * Math.sin(a2)); ctx.stroke();
  }

  // Curved, scalloped edge and glossy central highlight.
  ctx.strokeStyle = '#e45d7d';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-34, 0);
  for (let i = 0; i < 5; i++) {
    const a = Math.PI + (i + 1) * Math.PI / 5;
    const px = 34 * Math.cos(a), py = 34 * Math.sin(a);
    ctx.quadraticCurveTo(px - 2, py + 3, px, py);
  }
  ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,.7)';
  ctx.lineWidth = 3;
  ctx.beginPath(); ctx.arc(-8, -18, 12, 3.55, 4.8); ctx.stroke();
  ctx.fillStyle = '#fff5ed';
  ctx.beginPath(); ctx.arc(0, 0, 4, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#e45d7d';
  ctx.beginPath(); ctx.arc(0, 0, 2, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

function drawScene(time = 0) {
  drawBackground(time);
  clouds.forEach(cloud => drawCloudShape(cloud.x, cloud.y, cloud.scale, cloud.color));
  particles.forEach(p => {
    ctx.globalAlpha = Math.max(0, p.life / 35);
    ctx.fillStyle = p.color;
    ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2); ctx.fill();
  });
  ctx.globalAlpha = 1;
  if (player) drawUmbrella(player.x, player.y, time);
  ctx.fillStyle = 'rgba(255,255,255,.7)';
  ctx.fillRect(0, H - 2, W, 2);
}

function resetGame() {
  player = { x: W / 2, y: 116, width: 66, height: 61, speed: 5.4 };
  clouds = [];
  particles = [];
  score = 0;
  elapsed = 0;
  spawnTimer = 0;
  scoreLabel.textContent = '0';
}

function spawnCloud() {
  const scale = 1 + Math.random() * 0.17;
  clouds.push({
    x: 55 + Math.random() * (W - 110),
    y: -45,
    scale,
    speed: 2.15 + Math.min(elapsed / 18000, 2.2) + Math.random() * 0.65,
    color: ['#fffefa', '#fff8f1', '#f8fdff'][Math.floor(Math.random() * 3)]
  });
}

function makeBurst(x, y) {
  for (let i = 0; i < 22; i++) {
    const angle = Math.random() * Math.PI * 2;
    const speed = 1 + Math.random() * 4;
    particles.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, life: 35, size: 2 + Math.random() * 4, color: ['#ff8298', '#ffd36f', '#75cfc1'][i % 3] });
  }
}

function finishGame() {
  running = false;
  makeBurst(player.x, player.y);
  drawScene(performance.now());
  if (score > bestScore) {
    bestScore = score;
    bestLabel.textContent = bestScore;
    try { localStorage.setItem('langitCeriaBest', bestScore); } catch (_) {}
  }
  overlayTitle.textContent = 'Ups, tersenggol awan!';
  overlayText.textContent = `Skor kamu ${score} ${score === 1 ? 'poin' : 'poin'} — coba lagi dan terbang lebih jauh!`;
  startButton.innerHTML = 'Main lagi <span>↻</span>';
  overlay.classList.remove('hidden');
}

function update(delta) {
  if (!running) return;
  elapsed += delta;
  const step = delta / 16.67;
  if (keys.left) player.x -= player.speed * step;
  if (keys.right) player.x += player.speed * step;
  player.x = Math.max(40, Math.min(W - 40, player.x));

  spawnTimer += delta;
  const interval = Math.max(430, 1050 - elapsed / 55);
  if (spawnTimer >= interval) {
    spawnCloud();
    spawnTimer = 0;
  }

  for (let i = clouds.length - 1; i >= 0; i--) {
    const cloud = clouds[i];
    cloud.y += cloud.speed * step;
    const hitX = Math.abs(player.x - cloud.x) < 39 * cloud.scale;
    const hitY = Math.abs(player.y - cloud.y) < 37 * cloud.scale;
    if (hitX && hitY) {
      finishGame();
      return;
    }
    if (cloud.y > H + 50) {
      clouds.splice(i, 1);
      score++;
      scoreLabel.textContent = score;
    }
  }
  particles = particles.filter(p => p.life > 0);
  particles.forEach(p => { p.x += p.vx * step; p.y += p.vy * step; p.vy += .08 * step; p.life -= step; });
}

function frame(time) {
  const delta = Math.min(time - (lastTime || time), 40);
  lastTime = time;
  update(delta);
  drawScene(time);
  requestAnimationFrame(frame);
}

function startGame() {
  resetGame();
  running = true;
  overlay.classList.add('hidden');
}

startButton.addEventListener('click', startGame);
window.addEventListener('keydown', event => {
  if (['ArrowLeft', 'ArrowRight', 'a', 'A', 'd', 'D', ' '].includes(event.key)) event.preventDefault();
  if (event.key === 'ArrowLeft' || event.key.toLowerCase() === 'a') keys.left = true;
  if (event.key === 'ArrowRight' || event.key.toLowerCase() === 'd') keys.right = true;
  if ((event.key === ' ' || event.key === 'Enter') && !running) startGame();
});
window.addEventListener('keyup', event => {
  if (event.key === 'ArrowLeft' || event.key.toLowerCase() === 'a') keys.left = false;
  if (event.key === 'ArrowRight' || event.key.toLowerCase() === 'd') keys.right = false;
});
canvas.addEventListener('pointermove', event => {
  if (!running || event.buttons === 0) return;
  const rect = canvas.getBoundingClientRect();
  player.x = Math.max(40, Math.min(W - 40, (event.clientX - rect.left) * W / rect.width));
});
canvas.addEventListener('pointerdown', event => {
  if (!running) return;
  canvas.setPointerCapture(event.pointerId);
  const rect = canvas.getBoundingClientRect();
  player.x = Math.max(40, Math.min(W - 40, (event.clientX - rect.left) * W / rect.width));
});

resetGame();
drawScene();
requestAnimationFrame(frame);
